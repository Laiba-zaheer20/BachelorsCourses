﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1;

namespace Project2
{
    
    public class Project2ChildClass : BaseClass
    {
        public Project2ChildClass()
        {
            /* Accessing variables from another assembly */

            //MyPublicVariable = 1;
            //MyProtectedVariable = 2;
            //MyPrivateVariable = 3; 

            //MyInternalVariable = 3;
            //MyProctedtedInternalVariable = 4;
            //MyPrivateprotectedVariable = 5;
        }
    }

     class Project2ExternalClass
    {
        public Project2ExternalClass()
        {
            BaseClass baseClass = new BaseClass();
            #region [Public / Protected / Private ]

            //baseClass.MyPublicVariable = 1;
            //baseClass.MyProtectedVariable = 2;
            //baseClass.MyPrivateVariable = 3; 
            #endregion

            #region [Internal / Protected Internal / Private Protected]
            //baseClass.MyInternalVariable = 4; 
            //baseClass.MyProctedtedInternalVariable = 4;
            //baseClass.MyPrivateprotectedVariable = 5;
            #endregion
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            

        }
    }
}
