﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    public class BaseClass
    {
        public BaseClass()
        {

        }
        
        public int MyPublicVariable;
        protected int MyProtectedVariable;
        private int MyPrivateVariable;

        internal int MyInternalVariable;
        protected internal int MyProctedtedInternalVariable;
        private protected int MyPrivateprotectedVariable;

    }

    public class MyExternalClass
    {
        public MyExternalClass()
        {
            BaseClass baseClass = new BaseClass();
            #region [Public / Protected / Private ]

            //baseClass.MyPublicVariable = 1;
            //baseClass.MyProtectedVariable = 2; 
            //baseClass.MyPrivateVariable = 3; 
            #endregion

            #region [Internal / Protected Internal / Private Protected]
            baseClass.MyInternalVariable = 4 ; 
            //baseClass.MyProctedtedInternalVariable = 4; 
            //baseClass.MyPrivateprotectedVariable = 5; 
            #endregion
        }

    }

    public class MyChildClassProject1 : BaseClass
    {
        public MyChildClassProject1()
        {
            #region [Public / Protected / Private ]
            //MyPublicVariable = 1;
            //MyProtectedVariable = 2;
            //MyPrivateVariable 
            //#endregion
            #endregion
            #region [Internal / Protected Internal / Private Protected]
            MyInternalVariable = 3;
            //MyProctedtedInternalVariable = 4;
            //MyPrivateprotectedVariable = 5;

            #endregion
        }
    }
   
}
