﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week01Code3
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            
            s.SetName("Ahmed");
            
            //s.Name = "Ahmed";
            //s.Age = 20;
            Console.WriteLine(s);
            Console.ReadKey();
        }

       
    }

    interface IStudent
    {
        string Name { get; set; }
        int Age { get; set; }

    }
    public class Student
    {
        #region [Code # 1]
        private string _Name;
        public string GetName()
        {
            return _Name;
        }

        public void SetName(string StudentName)
        {
            _Name = StudentName;
        }

        #endregion


        #region [Code # 2]
        //private string _Name;
        //public string Name
        //{
        //    get
        //    {
        //        return _Name;
        //    }
        //    set
        //    {
        //        _Name = value;
        //    }
        //}

        #endregion

        #region [Code # 3]
        //public string Name { get; set; }
        ////public int Age { get; set; }
        #endregion

        //public override string ToString()
        //{
        //    return Name;
        //}
    }
}
