﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code2
{
    class Program
    {
        static int Main(string[] args)
        {
            if (args.Length == 2)
            {
                int output = int.Parse(args[0]) + int.Parse(args[1]);
                Console.WriteLine(output);
                Console.ReadKey();
                return 0;
            }
            else
                return -1;
        }
    }

}
