﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week01Code1
{
    class Program
    {
        static void Main(string[] args)
        {

            int age = Convert.ToInt32(Console.ReadLine());
          
            #region [commented code]
            //int age;
            //int.TryParse(Console.ReadLine(), out age);
            #endregion

            Console.WriteLine(age);
            Console.ReadKey();
        }
    }
}
